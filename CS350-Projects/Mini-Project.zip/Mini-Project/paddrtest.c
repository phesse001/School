#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  int x = 10;
  int y = 20;

  // use our system call to translate the virtual address of x and y into their physical addresses
  void* px = paddr(&x);
  void* py = paddr(&y);

  // print the virtual and physical address of x
  printf(1, "x virtual addr: 0x%x\n", &x);
  printf(1, "x physical addr: 0x%x\n", px);

  // print the virtual and physical address of y
  // (if all goes well, it should be the address exactly 4 bytes, i.e., sizeof int, after x)
  printf(1, "y virtual addr: 0x%x\n", &y);
  printf(1, "y physical addr: 0x%x\n", py);

  exit();
}