#include "types.h" // for specific types
#include "user.h" // for function calls
#include "param.h" //for NPROC
#include "pstat.h"

void ps(struct pstat * pstat)
{
    int i;
    for(i = 0; i < NPROC; i++)
    {
        if(pstat->inuse[i] == 1)
        {
             printf(1, "Tickets: %d PID: %d Ticks: %d\n", pstat->tickets[i], pstat->pid[i], pstat->ticks[i]);
        }
    }
}

int main(int argc, char ** argv)
{
    int pid1,pid2,pid3;
    //int p1 = 0,p2 = 0,p3 = 0;
    struct pstat * p = malloc(sizeof(struct pstat));
    int x = 0;
    // create three processes and exec 
    pid1 = fork();

    if(pid1 == 0)
    {
        settickets(300);
        //p1 = getpid();

        pid2 = fork();

        if(pid2 == 0)
        {
            settickets(200);
            //p2 = getpid();

            pid3 = fork();

            if(pid3 == 0)
            {
                // in the third child process
                settickets(100);
                //p3 = getpid();
                for(;;)
                {
                    x += 1;
                }
            }

            for(;;)
            {
                x += 1;
            }
        }

        for(;;)
        {
            x += 1;
        }
    }
    sleep(300); // sleep for 100 ticks
    settickets(10000);
    getpinfo(p); // we need to call getpinfo without it switching to another process
    ps(p);
    exit();
}
