#include "types.h" // for specific types
#include "user.h" // for function calls
#include "param.h" //for NPROC
#include "pstat.h"

void ps(struct pstat * pstat)
{
    int i;
    for(i = 0; i < NPROC; i++)
    {
        if(pstat->inuse[i] == 1)
        {
             printf(1, "Tickets: %d PID: %d Ticks: %d\n", pstat->tickets[i], pstat->pid[i], pstat->ticks[i]);
        }
    }
}

int main(int argc, char ** argv)
{
	struct pstat * p = malloc(sizeof(struct pstat));
	settickets(100);
	sleep(100);
	getpinfo(p);
	ps(p);
	exit();
}