#include "types.h"
#include "user.h" // for function calls

int main(int argc, char ** argv)
{
    sleep(300);
    exit();
}
