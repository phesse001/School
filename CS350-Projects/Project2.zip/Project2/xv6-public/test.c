#include "types.h" // for specific types
#include "user.h" // for function calls
#include "param.h" //for NPROC
#include "pstat.h"

void PS(struct pstat * pstat)
{
    int i;
    for(i = 0; i < NPROC; i++)
    {
        if(pstat->inuse[i] == 1)
        {
             printf(1, "Tickets: %d PID: %d Ticks: %d Inuse: %d\n", pstat->tickets[i], pstat->pid[i], pstat->ticks[i], pstat->inuse[i]);
        }
    }
}

int main(int argc, char ** argv)
{
    int pid;
    int p;
    struct pstat * ps = malloc(sizeof(struct pstat));
    p = getpid();
    settickets(100);
    printf(1,"I am the parent process and my pid is %d\n", p);
    getpinfo(ps); // fill in info to start
    PS(ps);
    pid = fork();
    
    if(pid == 0)
    {
        int pid2;
        static char * args[1];
        args[0] = 0;
        p = getpid();
        settickets(50);
        printf(1, "I am the child process... my pid is %d and I want 1000 tickets!\n", p);
        //settickets(1000);
        getpinfo(ps); // fill in updated info now that there is a child proc
        PS(ps);
        pid2 = fork();
        if(pid2 == 0)
        {
            p = getpid();
            settickets(25);
            printf(1,"I am the childs child... My pid is %d... I should also have 25 tickets\n", p);
            getpinfo(ps);
            PS(ps);
        }
        // exec some process
        wait(); // wait for childs child
        exec("ls", args);
    }

    wait(); // wait for child

    // now fill in and print pstat info
    getpinfo(ps);
    PS(ps);
    free(ps);
    exit(); // idk whether to call exit or return 0
}
