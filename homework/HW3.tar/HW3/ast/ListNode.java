import java_cup.runtime.*;

/**
 *
 * @author Peter Ohmann + <Patrick Hesse>
 */
public class ListNode extends ExpressionNode {

    public ListNode() {
        super();
    }

    @Override
    public String toString() {
        return "";
    }
}
